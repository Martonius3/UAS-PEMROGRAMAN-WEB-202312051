</div> <!-- penutup container -->
<footer class="text-center py-3">
    <small>&copy; <?= date('Y') ?> POS App</small>
</footer>
</body>

</html>